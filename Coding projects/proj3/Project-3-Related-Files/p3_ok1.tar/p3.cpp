#include "simulation.h"
#include <string.h>

void error_exit(ostringstream & debug_stream,int exit_state){
	ostringstream stream;
	stream<<debug_stream.str()<<endl;
	debug_print('r', stream.str());
	//debug_stream.clear();
	//stream.clear();
	//exit(-exit_state);
	exit(0);
	return;
}

bool open_file_succeed(ifstream& i_file, string file_name){
	i_file.open(file_name.c_str());
	if (i_file.fail()) return false;
	return true;
}

void check_files(int argc, char *argv[]){

	const string speciesSummaryFile = argv[1];
	const string worldFile = argv[2]; 


	ifstream iFile;
	if (!open_file_succeed(iFile, speciesSummaryFile)){
		cout<<"Error: Cannot open file "<<get_short_path(speciesSummaryFile, 2)<<"!"<<endl; 
		iFile.close();
		exit(0);
	}
	iFile.close();
	if(!open_file_succeed(iFile, worldFile)){
		cout<<"Error: Cannot open file "<<get_short_path(worldFile, 3)<<"!"<<endl; 
		iFile.close();
		exit(0);
	}
	
	iFile.close();
	// cerr<<get_short_path(speciesSummaryFile, 2)<<"j"<<endl;
	// cerr<<get_short_path(worldFile, 3)<<"l"<<endl;

	int species_num = get_line_num(argv[1])-1;
	for (int i = 0; i < species_num; ++i)
	{
		string name;
		ostringstream sStream;
		string line;
		string lines[MAXWORLDSIZE];
		string path = get_speciesFile(argv[1], i,name);
		if(!open_file_succeed(iFile, path)){
			cout<<"Error: Cannot open file "<<get_short_path(path, 3)<<"!"<<endl; 
			iFile.close();
		exit(0);
		}
		iFile.close();
		//cerr<<get_short_path(path, 3)<<endl;
	}

	
}

bool check_args(int argc, char *argv[]){
	ostringstream debug_stream;
	ostringstream oStream;
	if (argc<4){
		oStream<<"Error: Missing arguments!\nUsage: ./p3 <species-summary> <world-file> <rounds> [v|verbose]";
		error_exit(oStream, 1);
	}
	if (atoi(argv[3])<0) {
		oStream<<"Error: Number of simulation rounds is negative!";
		error_exit(oStream, 2);
	}
	
	check_files(argc, argv);
	debug_print('e', debug_stream.str());
	string species_name[MAXSPECIES];
	int species_num = get_line_num(argv[1])-1;
	if(species_num > int(MAXSPECIES)){
		oStream<<"Error: Too many species!\nMaximal number of species is "<<MAXSPECIES<<".";
		error_exit(oStream, 4);
	}
	bool species_too_much = false;
	for (int i = 0; i < species_num; ++i)
	{
		string name;
		ostringstream sStream;
		string path = get_speciesFile(argv[1], i,name);
		species_name[i] = name;
		if(get_line_num(path)>int(MAXPROGRAM)){
			sStream<<"Error: Too many instructions for species "<<name<<"!\nMaximal number of instructions is "<<MAXPROGRAM<<".";
			cout<<sStream.str();
			species_too_much = true;
		}
	}
	if(species_too_much) exit(5);
	for (int i = 0; i < species_num; ++i)
	{
		string name;
		ostringstream sStream;
		string line;
		string lines[MAXWORLDSIZE];
		string path = get_speciesFile(argv[1], i,name);
		debug_stream<<"species <"<<name<<">";
		int programSize;

		file_handle(path, programSize, lines);
		

		for (int j = 0; j < programSize; ++j)
		{
			string operation;
			line = lines[j];
			string words[MAXARGINLINE];
			split(line, ' ', words);
			operation = words[0];
			debug_stream<<"operation: "<<operation<<endl;
			if(!str_in_opcode(operation)){
				debug_print('d', debug_stream.str());
				oStream<<"Error: Instruction "<<operation<<" is not recognized!";
				error_exit(oStream, 6);
			}
		}
	}
//------------------------------* 7,8,9 *-----------------------------------//
	int h, w;
	string error_string = "No Error";
	terrain_t terrain[MAXHEIGHT][MAXWIDTH];
	world_message(argv[2], h, w, terrain, error_string);
	if(h>int(MAXHEIGHT) || h<0) {
		oStream<<"Error: The grid height is illegal!";
		error_exit(oStream, 7);
	}
	if(w>int(MAXWIDTH) || w<0){
		oStream<<"Error: The grid width is illegal!";
		error_exit(oStream, 8);
	}
	for (int i = 0; i < h; ++i)
	{
		for (int j = 0; j < w; ++j)
		{
			if(terrain[i][j] == TERRAIN_SIZE){
				oStream<<"Error: Terrain square ("<<error_string<<" "<<i<<" "<<j<<") is invalid!";
				error_exit(oStream, 9);
			}
		}
	}
//------------------------------* 10 *-----------------------------------//
	int creature_num = get_creature_num(argv[2]);
	debug_stream<<"creature_num: "<<creature_num<<endl;
	if(creature_num > int(MAXCREATURES)) {
		oStream<<"Error: Too many creatures!\nMaximal number of creatures is "<<MAXCREATURES<<".";
		error_exit(oStream, 10);
	}
//------------------------------* 11 *-----------------------------------//
	string line;
	string lines[MAXWORLDSIZE];
	int line_num;
	file_handle(argv[2], line_num, lines);
	for (int i = 0; i < creature_num; ++i)
	{
		bool creature_exist = false;
		line = lines[h+2+i];
		string words[MAXARGINLINE];
		split(line, ' ', words);
		for (int i = 0; i < species_num; ++i)
		{
			if(species_name[i] == words[0]) {creature_exist = true;}
		}
		if (!creature_exist) {
			oStream<<"Error: Species "<<words[0]<<" not found!";
			error_exit(oStream, 11);
		}
	}
//------------------------------* 12 *-----------------------------------//
	for (int i = 0; i < creature_num; ++i)
	{
		bool direction_exist = false;
		line = lines[h+2+i];
		string words[MAXARGINLINE];
		split(line, ' ', words);
		for (int i = 0; i < DIRECT_SIZE; ++i)
		{
			if(directName[i] == words[1]) {direction_exist = true;}
		}
		if (!direction_exist) {
			oStream<<"Error: Direction "<<words[1]<<" is not recognized!";
			error_exit(oStream, 11);
		}
	}
//------------------------------* 13 *-----------------------------------//
	for (int i = 0; i < creature_num; ++i)
	{
		bool creature_out_of_bound = false;
		line = lines[h+2+i];
		string words[MAXARGINLINE];
		split(line, ' ', words);
		int creature_h = atoi(words[2].c_str());
		int creature_w = atoi(words[3].c_str());
		if(creature_h+1>h || creature_w+1>w) {creature_out_of_bound = true;}
		if (creature_out_of_bound) {
			oStream<<"Error: Creature ("<<words[0]<<" "<<words[1]<<" "<<words[2]<<" "<<words[3]<<") is out of bound!\nThe grid size is "<<h<<"-by-"<<w<<".";
			error_exit(oStream, 13);
		}
	}
//------------------------------* 14 *-----------------------------------//
	for (int i = 0; i < creature_num; ++i)
	{
		bool creature_ability_invalid  = false;
		line = lines[h+2+i];
		string words[MAXARGINLINE];
		split(line, ' ', words);
		string invalid_ability;
		for (int j = 0; j < MAXABILITYNUM; ++j)
		{
			if(words[4+j]!="" && words[4+j]!="f" && words[4+j]!="a"){
				creature_ability_invalid = true;
				invalid_ability = words[4+j];
			}
		}
		if (creature_ability_invalid) {
			oStream<<"Error: Creature ("<<words[0]<<" "<<words[1]<<" "<<words[2]<<" "<<words[3]<<") has an invalid ability "<<invalid_ability<<"!";
			error_exit(oStream, 14);
		}
	}
//------------------------------* 15 *-----------------------------------//
	point_t creatures_A_B;
	point_t points[MAXCREATURES];
	bool creature_overlaps  = false;
	for (int i = 0; i < creature_num; ++i)
	{
		line = lines[h+2+i];
		string words[MAXARGINLINE];
		split(line, ' ', words);
		points[i].r = atoi(words[2].c_str());
		points[i].c = atoi(words[3].c_str());
		for (int j = 0; j < i; ++j)
		{
			if(points[i].r == points[j].r && points[i].c == points[j].c){
				creature_overlaps = true;
				creatures_A_B.r = i;
				creatures_A_B.c = j;
			}
		}
	}

	if (creature_overlaps) {
		string words[MAXARGINLINE];
		split(lines[creatures_A_B.r+2+h], ' ', words);
		oStream<<"Error: Creature ("<<words[0]<<" "<<words[1]<<" "<<words[2]<<" "<<words[3]<<") overlaps with creature (";
		split(lines[creatures_A_B.c+2+h], ' ', words);
		oStream<<words[0]<<" "<<words[1]<<" "<<words[2]<<" "<<words[3]<<")!";
		error_exit(oStream, 15);
	}
//------------------------------* 16 *-----------------------------------//
	for (int i = 0; i < h; ++i)
	{
		for (int j = 0; j < w; ++j)
		{
			if(terrain[i][j] == LAKE){
				debug_stream<<i<<" "<<j <<" = lake"<<endl;
				for (int k = 0; k<creature_num; ++k){
					string words[MAXARGINLINE];
					split(lines[k+2+h], ' ', words);
					if (atoi(words[2].c_str()) == i && atoi(words[3].c_str()) == j) {
						if (!ability_exist(lines[k+2+h], FLY))
						{
							oStream<<"Error: Creature ("<<words[0]<<" "<<words[1]<<" "<<words[2]<<" "<<words[3]<<") is in a lake square!";
							error_exit(oStream, 16);
						}
					}
				}
			}
		}
	}
	return true;
}

bool verbose_on(int argc, char *argv[]){
	if(argc == 4) return false;
	if(strcmp(argv[4] , "v") == 0 || strcmp(argv[5],"verbose")) return true;
	return false;
}

int main(int argc, char *argv[]) {
	check_args(argc, argv);
	world_t wd;
	const string speciesSummaryFile = argv[1];
	const string worldFile = argv[2]; 
	initWorld(wd, speciesSummaryFile, worldFile);
	const grid_t grid = wd.grid;
	bool verbose = verbose_on(argc, argv);
	int rounds = atoi(argv[3]);
	cout<<"Initial state"<<endl;




	
	//exit(0);


	printGrid(grid);
	simulation(wd, verbose, rounds);

	// cout<<wd.creatures[0].species->name<<" "<< wd.creatures[1].species->name<<endl;
	// for (int i = 0; i < wd.creatures[0].species->programSize; ++i)
	// {
	// 	cout<<opName[wd.creatures[0].species->program[i].op]<<endl;
	// }
	// for (int i = 0; i < wd.creatures[1].species->programSize; ++i)
	// {
	// 	cout<<opName[wd.creatures[1].species->program[i].op]<<endl;
	// }
	
	// direction_t dir = EAST;
	// cout<<"RIGHT:"<<endl;
	// point_t point;
	// set_point(point, 0,0);
	// for (int i = 0; i < 10; ++i)
	// {

	// 	cerr<<"direction: "<<directName[rightFrom(dir)]<<endl;
	// 	cout<<point_t_string(point);
	// 	point = adjacentPoint(point, dir);
	// 	dir = rightFrom(dir);
	// }
	// cout<<"LEFT:"<<endl;
	// for (int i = 0; i < 10; ++i)
	// {
	// 	cerr<<"direction: "<<directName[leftFrom(dir)]<<endl;
	// 	dir = leftFrom(dir);
	// }
	return 0;
}
























