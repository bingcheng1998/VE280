#include "player.h"
#include <iostream>

using namespace std;

// --------------------------------Simple----------------------------------

class Simple: public Player
{
 //unsigned int S_bet;
// unsigned int S_bankroll;
//Hand S_hand;
public:
	Simple();

	int bet(unsigned int bankroll, unsigned int minimum); 

    bool draw(Card dealer, const Hand &player); 

    void expose(Card c);

    void shuffled();
};

Simple::Simple()
{
	// Hand hand;
	// S_hand = hand;
}

int Simple::bet(unsigned int bankroll, unsigned int minimum)
{
	// S_bet = minimum;
	// return S_bet;
	return minimum;
}

bool Simple::draw(Card dealer, const Hand &player)
{
	//S_hand.curValue = player.curValue;
	int count = player.handValue().count;
	Spot spot = dealer.spot;
	// cout<<"DEBUG:soft"<<player.handValue().soft<<" count:"<<count<<endl;
	if (player.handValue().soft == false)
	{
		// cout<<"DEBUG:"<<SpotNames[spot]<<endl;
		if(count <= 11) return true;
		if(count == 12 && !(spot>=FOUR && spot <=SIX )) return true;
		if(count <=16 && count >=13 && !(spot >= TWO && spot <= SIX)) return true;
		if(count >= 17) return false;
		return false;
	} else return false;
	count -= 10;
	//S_hand.soft = false;
	//player.curValue = S_hand.curValue;
	if(count <= 11) return true;
	if(count == 12 && !(spot>THREE && spot < SEVEN )) return true;
	if(count <17 && count > 12 && !(spot >= TWO && spot <= SIX)) return true;
	if(count >= 17) return false;
	count += 10;
	//S_hand.soft = true;
	//player = S_hand;
	if(count <= 17 ) return true;
	if(count == 18 && !((spot == TWO || spot == SEVEN || spot == EIGHT))) return true;
	if(!(count >= 19)) return true;
	return false;
}

void Simple::expose(Card c)
{
}

void Simple::shuffled()
{
}

static Simple simple;

extern Player *get_Simple(){
	return &simple;
}

// ---------------------------------Counting---------------------------------

class Counting: public Simple
{
	int count;

public:
	Counting();

	int bet(unsigned int bankroll, unsigned int minimum); 

    void expose(Card c);

    void shuffled();
};

Counting::Counting():count(0)
{

}

int Counting::bet(unsigned int bankroll, unsigned int minimum)
{
	//cout<<"👌 "<<bankroll<<" "<<minimum<<endl;
	if (count >= 2 && bankroll >= minimum * 2)
	{
		return minimum * 2;
	}
	return minimum;
}


void Counting::expose(Card c)
{
	if (c.spot>=TEN)
	{
		count -- ;
	} else if(c.spot>=TWO && c.spot <= SIX){
		count ++ ;
	}
}

void Counting::shuffled()
{
	count = 0;
}

static Counting counting;

extern Player *get_Counting(){
	return &counting;
}


