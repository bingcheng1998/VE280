#include <iostream>
#include <sstream>
#include <fstream>
#include <iomanip>
#include <string>
#include <cstdlib>
#include <cassert>

#include "player.h"
#include "rand.h"
#include "deck.h"

using namespace std;

#define CUTNUMBER 7

int player_wins(const Hand &h_player, const Hand &h_dealer);
int total_count(Hand hand);
string card2str(Card card);
void file_shuffle(Deck &deck, char* file_name);
void random_shuffle(Deck &deck);

int main(int argc, char *argv[]) {
	Deck deck;
	assert(argc > 3);
	int input_file = false;
	if(argc > 5) input_file = true;
	int bankroll = atoi(argv[1]);
	int min_bet = atoi(argv[2]);
	int hands = atoi(argv[3]);
	string s_simple = "simple";
	bool simple_player = (s_simple.c_str() == argv[4]);
	if (input_file)
	{
		file_shuffle(deck, argv[5]);
	} else {
		random_shuffle(deck);
	}
	Hand h_player, h_dealer;
	Card dealer;
	//-----------------------------以下没有复用-----------------------------
	// if (simple_player)
	// {
	// 	Player *simple = get_Simple();
	// 	for (int i = 0; i < hands; ++i)
	// 	{
	// 		if (deck.cardsLeft()<20)
	// 		{
	// 			random_shuffle(deck);
	// 		}
	// 		Card card;
	// 		cout<<"# Hand "<<i+1<<" bankroll "<<bankroll<<endl;
	// 		cout<<"# Player bets "<<simple->bet(bankroll, min_bet)<<endl;
	// 		//simple->bet(bankroll, min_bet);
	// 		try {
	// 			card = deck.deal();
	// 			cout<<"Player dealt "<<card2str(card)<<endl;
	// 			h_player.addCard(card);

	// 			dealer = deck.deal();
	// 			cout<<"Dealer dealt "<<card2str(dealer)<<endl;
	// 			h_dealer.addCard(dealer);

	// 			card = deck.deal();
	// 			cout<<"Player dealt "<<card2str(card)<<endl;
	// 			h_player.addCard(card);

	// 			bool hit = simple->draw(dealer, h_player);
				
	// 			dealer = deck.deal();
	// 			h_dealer.addCard(dealer);

	// 			//判断player是否抓牌
	// 			while(hit)
	// 			{
	// 				card = deck.deal();
	// 				cout<<"Player dealt "<<card2str(card)<<endl;
	// 				h_player.addCard(card);
	// 				hit = simple->draw(dealer, h_player);
	// 			}
	// 		}
	// 		catch (DeckEmpty n){cerr<<"Empty!"<<endl;}

	// 		if (total_count(h_player) >= 21)
	// 		{
				
	// 		} else {
	// 			cout<<"Player's total is "<<total_count(h_player)<<endl;
	// 			cout<<"Dealer's hole card is "<<card2str(dealer)<<endl;
	// 			//👮进行dealer是否抓牌判断

	// 			while(h_dealer.handValue().count<17 || ((h_dealer.handValue().count>=17 && h_dealer.handValue().count - 10 <17) && h_dealer.handValue().soft)){
	// 				dealer = deck.deal();
	// 				cout<<"Dealer dealt "<<card2str(dealer)<<endl;
	// 				h_dealer.addCard(dealer);
	// 			}


	// 			cout<<"Dealer's total is "<<total_count(h_dealer)<<endl;

				

	// 		}
	// 		int p_wins = player_wins(h_player, h_dealer);
	// 		h_player.discardAll();
	// 		h_dealer.discardAll();
	// 		if( p_wins == 2){
	// 			bankroll += (simple->bet(bankroll, min_bet) *3)/2;
	// 		} else if(p_wins < 0){
	// 			bankroll -= simple->bet(bankroll, min_bet);
	// 		} else if(p_wins == 1){
	// 			bankroll += simple->bet(bankroll, min_bet);
	// 		}
	// 	}
	// 	cout<<"# Player has "<<bankroll<<" after "<<hands<<" hands"<<endl;
	// } else {
	// 	Player *counting = get_Counting();
	// 	for (int i = 0; i < hands; ++i)
	// 	{
	// 		if (deck.cardsLeft()<20)
	// 		{
	// 			random_shuffle(deck);
	// 			counting->shuffled();
	// 		}
	// 		Card card;
	// 		cout<<"# Hand "<<i+1<<" bankroll "<<bankroll<<endl;
	// 		cout<<"# Player bets "<<counting->bet(bankroll, min_bet)<<endl;
	// 		//simple->bet(bankroll, min_bet);
	// 		try {
	// 			card = deck.deal();
	// 			counting->expose(card);
	// 			cout<<"Player dealt "<<card2str(card)<<endl;
	// 			h_player.addCard(card);

	// 			dealer = deck.deal();
	// 			counting->expose(dealer);
	// 			cout<<"Dealer dealt "<<card2str(dealer)<<endl;
	// 			h_dealer.addCard(dealer);

	// 			card = deck.deal();
	// 			counting->expose(card);
	// 			cout<<"Player dealt "<<card2str(card)<<endl;
	// 			h_player.addCard(card);

	// 			bool hit = counting->draw(dealer, h_player);
				
	// 			dealer = deck.deal();
	// 			h_dealer.addCard(dealer);

	// 			//判断player是否抓牌
	// 			while(hit)
	// 			{
	// 				card = deck.deal();
	// 				counting->expose(card);
	// 				cout<<"Player dealt "<<card2str(card)<<endl;
	// 				h_player.addCard(card);
	// 				hit = counting->draw(dealer, h_player);
	// 			}
	// 		}
	// 		catch (DeckEmpty n){cerr<<"Empty!"<<endl;}

	// 		if (total_count(h_player) >= 21)
	// 		{
				
	// 		} else {
	// 			cout<<"Player's total is "<<total_count(h_player)<<endl;
	// 			cout<<"Dealer's hole card is "<<card2str(dealer)<<endl;
	// 			counting->expose(dealer);
	// 			//👮进行dealer是否抓牌判断

	// 			while(h_dealer.handValue().count<17 || ((h_dealer.handValue().count>=17 && h_dealer.handValue().count - 10 <17) && h_dealer.handValue().soft)){
	// 				dealer = deck.deal();
	// 				counting->expose(dealer);
	// 				cout<<"Dealer dealt "<<card2str(dealer)<<endl;
	// 				h_dealer.addCard(dealer);
	// 			}


	// 			cout<<"Dealer's total is "<<total_count(h_dealer)<<endl;

				

	// 		}
	// 		int p_wins = player_wins(h_player, h_dealer);
	// 		h_player.discardAll();
	// 		h_dealer.discardAll();
	// 		if( p_wins == 2){
	// 			bankroll += (counting->bet(bankroll, min_bet) *3)/2;
	// 		} else if(p_wins < 0){
	// 			bankroll -= counting->bet(bankroll, min_bet);
	// 		} else if(p_wins == 1){
	// 			bankroll += counting->bet(bankroll, min_bet);
	// 		}
	// 	}
	// 	cout<<"# Player has "<<bankroll<<" after "<<hands<<" hands"<<endl;
	// }
	//-----------------------以上没有复用-------------------------------
	Player *player;
	if (simple_player)
	{
		player = get_Simple();
	} else 
	{
		player = get_Counting();
	}

		for (int i = 0; i < hands; ++i)
		{
			if (deck.cardsLeft()<20)
			{
				random_shuffle(deck);
			}
			Card card;
			cout<<"# Hand "<<i+1<<" bankroll "<<bankroll<<endl;
			cout<<"# Player bets "<<player->bet(bankroll, min_bet)<<endl;
			//simple->bet(bankroll, min_bet);
			try {
				card = deck.deal();
				cout<<"Player dealt "<<card2str(card)<<endl;
				h_player.addCard(card);

				dealer = deck.deal();
				cout<<"Dealer dealt "<<card2str(dealer)<<endl;
				h_dealer.addCard(dealer);

				card = deck.deal();
				cout<<"Player dealt "<<card2str(card)<<endl;
				h_player.addCard(card);

				bool hit = player->draw(dealer, h_player);
				
				dealer = deck.deal();
				h_dealer.addCard(dealer);

				//判断player是否抓牌
				while(hit)
				{
					card = deck.deal();
					cout<<"Player dealt "<<card2str(card)<<endl;
					h_player.addCard(card);
					hit = player->draw(dealer, h_player);
				}
			}
			catch (DeckEmpty n){cerr<<"Empty!"<<endl;}

			if (total_count(h_player) >= 21)
			{
				
			} else {
				cout<<"Player's total is "<<total_count(h_player)<<endl;
				cout<<"Dealer's hole card is "<<card2str(dealer)<<endl;
				//👮进行dealer是否抓牌判断

				while(h_dealer.handValue().count<17 || ((h_dealer.handValue().count>=17 && h_dealer.handValue().count - 10 <17) && h_dealer.handValue().soft)){
					dealer = deck.deal();
					cout<<"Dealer dealt "<<card2str(dealer)<<endl;
					h_dealer.addCard(dealer);
				}


				cout<<"Dealer's total is "<<total_count(h_dealer)<<endl;

				

			}
			int p_wins = player_wins(h_player, h_dealer);
			h_player.discardAll();
			h_dealer.discardAll();
			if( p_wins == 2){
				bankroll += (player->bet(bankroll, min_bet) *3)/2;
			} else if(p_wins < 0){
				bankroll -= player->bet(bankroll, min_bet);
			} else if(p_wins == 1){
				bankroll += player->bet(bankroll, min_bet);
			}
		}
		cout<<"# Player has "<<bankroll<<" after "<<hands<<" hands"<<endl;
	
	
}

int total_count(Hand hand){
	if(!hand.handValue().soft) return hand.handValue().count;
	if(hand.handValue().count<=21) return hand.handValue().count;
	return hand.handValue().count-10;
}

int player_wins(const Hand &h_player, const Hand &h_dealer){//所有的win、 bust等结果在这里输出，返回false则player要输钱。
	//cout<<"DEBUG: D: "<< total_count(h_dealer) <<", P: "<< total_count(h_player)<<endl;
	if(total_count(h_player) == 21){
		cout << "# Player dealt natural 21\n";
		return 2;
	}
	if(total_count(h_player)>21) {
		cout<<"Player's total is "<<total_count(h_player)<<endl;
		cout << "# Player busts\n";
		return -1;
	} 
	if (total_count(h_dealer)>21)
	{
		cout << "# Dealer busts\n";
		return 1;
	}
	if (total_count(h_dealer) > total_count(h_player))
	{
		cout << "# Dealer wins\n";
		return -1;
	}
	if (total_count(h_dealer) < total_count(h_player))
	{
		cout << "# Player wins\n";
		return 1;
	}
	cout << "# Push\n";
	return 0;
}

void file_shuffle(Deck &deck, char* file_name){
	ifstream i_file;
	i_file.open(file_name);
	int shuffle_point_length = 0;
	if (i_file.fail()) {
	cout<<"Error: Cannot open file "<< file_name<<" !"<<endl; 
		exit(0);
	}
	cout << "# Shuffling the deck\n";
	string line;
	getline(i_file, line);
	istringstream iStream;
	iStream.str(line);
	//cout<<line<<endl;
	while(iStream){
		int shuffle_point;
		iStream >> shuffle_point;
		if (!iStream) break;
		shuffle_point_length++;
		deck.shuffle(shuffle_point);
	}
	assert(shuffle_point_length>-1);
	i_file.close();
}

void random_shuffle(Deck &deck){
	cout << "# Shuffling the deck\n";
	for (int i = 0; i < CUTNUMBER; ++i)
	{
		deck.shuffle(get_cut());
	}
}

string card2str(Card card){
	ostringstream card_stream;
	card_stream<<SpotNames[card.spot]<<" of "<<SuitNames[card.suit];
	return card_stream.str();
}







































