#include "hand.h"
#include <iostream>
#include <cassert>
using namespace std;

/*
struct HandValue {
    int  count;    // Value of hand
    bool soft;     // true if hand value is a soft count
};*/

Hand::Hand()     //默认soft为false，当出现A自动转为true，而且A默认为11。超出21，A转为false。
// EFFECTS: establishes an empty blackjack hand.
{
    curValue.soft = false;
    curValue.count = 0;
}

void Hand::discardAll()
// MODIFIES: this
    // EFFECTS: discards any cards presently held, restoring the state
    // of the hand to that of an empty blackjack hand.
{
    curValue.soft = false;
    curValue.count = 0;
}

void Hand::addCard(Card c)
    // MODIFIES: this
    // EFFECTS: adds the card "c" to those presently held.
{
    assert(c.spot < SPOT_SIZE);
    if (c.spot < JACK)
    {
        curValue.count += (c.spot+2);
    } else if(c.spot < ACE){
        curValue.count += 10;
    } else {
        curValue.count += 11;
        curValue.soft = true;
    }
}

HandValue Hand::handValue() const
	// EFFECTS: returns the present value of the blackjack hand.  The
    // count field is the highest blackjack total possible without
    // going over 21.  The soft field should be true if and only if at
    // least one ACE is present, and its value is counted as 11 rather
    // than 1.  If the hand is over 21, any value over 21 may be returned.
    //
    // Note: the const qualifier at the end of handValue means that
    // you are not allowed to change any member variables inside
    // handValue. Adding this prevents the accidental change by you.
{
    return curValue;
}