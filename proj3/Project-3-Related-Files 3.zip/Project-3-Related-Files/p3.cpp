#include "simulation.h"
//#include "world_type.h"

void error_exit(const string error,int exit_state){
	cout<<error<<endl;
	exit(exit_state);
}

void check_args(int argc, char *argv[]){
	ostringstream debug_stream;
	if (argc<4){
		error_exit("Error: Missing arguments!\nUsage: ./p3 <species-summary> <world-file> <rounds> [v|verbose]", -1);
	}
	if (atoi(argv[3])<0) error_exit("Error: Number of simulation rounds is negative!", -2);
	ifstream iFile;
	safe_open_file(iFile, argv[1]);
	iFile.close();
	safe_open_file(iFile, argv[2]);
	iFile.close();


	int species_num = get_line_num(argv[1])-1;
	ostringstream oStream;
	//debug_stream<<"species 的数量为："<<species_num<<endl;
	debug_print('e', debug_stream.str());
	string species_name[MAXSPECIES];
	if(species_num > MAXSPECIES){
		oStream<<"Error: Too many species!\nMaximal number of species is "<<MAXSPECIES<<".";
		error_exit(oStream.str(), -4);
	}
	bool species_too_much = false;
	for (int i = 0; i < species_num; ++i)
	{
		string name;
		ostringstream sStream;
		string path = get_speciesFile(argv[1], i,name);
		species_name[i] = name;
		if(get_line_num(path)>MAXPROGRAM){
			sStream<<"Error: Too many instructions for species "<<name<<"!\nMaximal number of instructions is "<<MAXPROGRAM<<"."<<endl;
			cout<<sStream.str();
			species_too_much = true;
		}
	}
	if(species_too_much) exit(-5);
	for (int i = 0; i < species_num; ++i)
	{
		string name;
		ostringstream sStream;
		string line;
		string *lines = new string[MAXWORLDSIZE];
		string path = get_speciesFile(argv[1], i,name);
		debug_stream<<"物种<"<<name<<">"<<endl;
		int programSize;

		file_handle(path, programSize, lines);
		

		for (int j = 0; j < programSize; ++j)
		{
			// line = lines[j];
			// istringstream iStream;
			// string operation;
			// iStream.str(line);
			// iStream >> operation;
				// cout<<"operation: "<<operation<<endl;
			string operation;
			line = lines[j];
			string words[MAXARGINLINE];
			split(line, ' ', words);
			operation = words[0];
			debug_stream<<"operation: "<<operation<<endl;
			if(!str_in_opcode(operation)){
				debug_print('d', debug_stream.str());
				oStream<<"Error: Instruction "<<operation<<" is not recognized!"<<endl;
				error_exit(oStream.str(), -6);
			}
		}
	}
//------------------------------* 9 *-----------------------------------//
	int h, w;
	string error_string = "No Error";
	terrain_t terrain[MAXHEIGHT][MAXWIDTH];
	//grid_t grid;
	world_message(argv[2], h, w, terrain, error_string);
	if(h>MAXHEIGHT) error_exit("Error: The grid height is illegal!", -7);
	if(w>MAXWIDTH) error_exit("Error: The grid width is illegal!", -8);
	//cout<<"h"<<h<<"w"<<w<<endl;
	for (int i = 0; i < h; ++i)
	{
		for (int j = 0; j < w; ++j)
		{
			if(terrain[i][j] == TERRAIN_SIZE){
				oStream<<"Error: Terrain square ("<<error_string<<" "<<i<<" "<<j<<") is invalid!"<<endl;
				error_exit(oStream.str(), -7);
			}
		}
	}
//------------------------------* 10 *-----------------------------------//
	int creature_num = get_creature_num(argv[2]);
	//cout<<"creature_num: "<<creature_num<<endl;
	if(creature_num > MAXCREATURES) {
		oStream<<"Error: Too many creatures!\nMaximal number of creatures is "<<MAXCREATURES<<"."<<endl;
		error_exit(oStream.str(), 10);
	}
//------------------------------* 11 *-----------------------------------//
	string line;
	string *lines = new string[MAXWORLDSIZE];
	int line_num;
	file_handle(argv[2], line_num, lines);
	for (int i = 0; i < creature_num; ++i)
	{
		bool creature_exist = false;
		line = lines[h+2+i];
		//debug_stream<<"取出第 "<< i <<" 个生物: "<<line<<endl;
		string words[MAXARGINLINE];
		split(line, ' ', words);
		for (int i = 0; i < species_num; ++i)
		{
			if(species_name[i] == words[0]) {creature_exist = true;}
		}
		if (!creature_exist) {
			oStream<<"Error: Species "<<words[0]<<" not found!";
			error_exit(oStream.str(), 11);
		}
	}
//------------------------------* 12 *-----------------------------------//
	for (int i = 0; i < creature_num; ++i)
	{
		bool direction_exist = false;
		line = lines[h+2+i];
		//debug_stream<<"取出第 "<< i <<" 个生物: "<<line<<endl;
		string words[MAXARGINLINE];
		split(line, ' ', words);
		for (int i = 0; i < DIRECT_SIZE; ++i)
		{
			if(directName[i] == words[1]) {direction_exist = true;}
		}
		if (!direction_exist) {
			oStream<<"Error: Direction "<<words[1]<<" is not recognized!";
			error_exit(oStream.str(), 11);
		}
	}
//------------------------------* 13 *-----------------------------------//
	for (int i = 0; i < creature_num; ++i)
	{
		bool creature_out_of_bound = false;
		line = lines[h+2+i];
		//debug_stream<<"取出第 "<< i <<" 个生物: "<<line<<endl;
		string words[MAXARGINLINE];
		split(line, ' ', words);
		// for (int i = 0; i < species_num; ++i)
		// {
			int creature_h = atoi(words[2].c_str());
			int creature_w = atoi(words[3].c_str());
			// cout<<"words[4]"<<words[4]<<"words[5]"<<words[5]<<"."<<endl;
			// if(words[4] != "" && words[5] =! ""){
			// 	cout<<"words[4]&[5] 为空"<<endl;
			// }
			//cout<<line<<" " <<h<<" "<<w<<endl;
			if(creature_h+1>h || creature_w+1>w) {creature_out_of_bound = true;}
		// }
		if (creature_out_of_bound) {
			oStream<<"Error: Creature ("<<words[0]<<" "<<words[1]<<" "<<words[2]<<" "<<words[3]<<") is out of bound!\nThe grid size is 3-by-3.";
			error_exit(oStream.str(), 13);
		}
	}
//------------------------------* 14 *-----------------------------------//
	for (int i = 0; i < creature_num; ++i)
	{
		bool creature_ability_invalid  = false;
		line = lines[h+2+i];
		//debug_stream<<"取出第 "<< i <<" 个生物: "<<line<<endl;
		string words[MAXARGINLINE];
		split(line, ' ', words);
		string invalid_ability;
		// for (int i = 0; i < species_num; ++i)
		// {
			// int creature_h = atoi(words[2].c_str());
			// int creature_w = atoi(words[3].c_str());
			//cout<<"words[4]"<<words[4]<<"words[5]"<<words[5]<<"."<<endl;
			for (int j = 0; j < MAXABILITYNUM; ++j)
			{
				if(words[4+j]!="" && words[4+j]!="f" && words[4+j]!="a"){
					creature_ability_invalid = true;
					invalid_ability = words[4+j];
					//cout<<"invalid_ability: "<<invalid_ability<<endl;
				}
			}
			//cout<<line<<" " <<h<<" "<<w<<endl;
			//if(creature_h+1>h || creature_w+1>w) {creature_out_of_bound = true;}
		// }
		if (creature_ability_invalid) {
			oStream<<"Error: Creature ("<<words[0]<<" "<<words[1]<<" "<<words[2]<<" "<<words[3]<<") has an invalid ability "<<invalid_ability<<"!"<<endl;;
			error_exit(oStream.str(), 14);
		}
	}
//------------------------------* 15 *-----------------------------------//
	point_t creatures_A_B;
	point_t points[MAXCREATURES];
	bool creature_overlaps  = false;
	for (int i = 0; i < creature_num; ++i)
	{
		
		line = lines[h+2+i];
		//debug_stream<<"取出第 "<< i <<" 个生物: "<<line<<endl;
		string words[MAXARGINLINE];
		split(line, ' ', words);
		points[i].r = atoi(words[2].c_str());
		points[i].c = atoi(words[3].c_str());
		for (int j = 0; j < i; ++j)
		{
			if(points[i].r == points[j].r && points[i].c == points[j].c){
				creature_overlaps = true;
				creatures_A_B.r = i;
				creatures_A_B.c = j;
			}
		}
		
	}

	if (creature_overlaps) {
		string words[MAXARGINLINE];
		split(lines[creatures_A_B.r+2+h], ' ', words);
		// point_t locationA, locationB;
		// creature_t creatureA = creature_make(argv[2], creatures_A_B.r, locationA);
		// creature_t creatureB = creature_make(argv[2], creatures_A_B.c, locationB);
		oStream<<"Error: Creature ("<<words[0]<<" "<<words[1]<<" "<<words[2]<<" "<<words[3]<<") overlaps with creature (";
		split(lines[creatures_A_B.c+2+h], ' ', words);
		oStream<<words[0]<<" "<<words[1]<<" "<<words[2]<<" "<<words[3]<<")!"<<endl;;
		//oStream<<"no"<<endl;
		error_exit(oStream.str(), 15);
	}
//------------------------------* 16 *-----------------------------------//
	//bool lake_fly = true;
	for (int i = 0; i < h; ++i)
	{
		for (int j = 0; j < w; ++j)
		{
			if(terrain[i][j] == LAKE){
				cout<<i<<" "<<j <<" = lake"<<endl;
				for (int k = 0; k<creature_num; ++k){
					string words[MAXARGINLINE];
					split(lines[k+2+h], ' ', words);
					if (atoi(words[2].c_str()) == i && atoi(words[3].c_str()) == j) {
						if (!ability_exist(lines[k+2+h], FLY))
						{
							oStream<<"Error: Creature ("<<words[0]<<" "<<words[1]<<" "<<words[2]<<" "<<words[3]<<") is in a lake square!"<<endl;
							error_exit(oStream.str(), 16);
						}
					}
				}
				
				
			}
		}
	}
}

bool verbose_on(int argc, char *argv[]){
	if(argc == 4) return false;
	cout<<"argv[4]"<<argv[4];
	if(strcmp(argv[4] , "v") == 0 || strcmp(argv[5],"verbose")) return true;
	return false;
}

int main(int argc, char *argv[]) {
	check_args(argc, argv);
	world_t wd;
	// const string speciesFile = "/Users/bingcheng/Desktop/VE280/proj3/Project-3-Related-Files/Tests/creatures/landmine";
	// const string worldFile = "/Users/bingcheng/Desktop/VE280/proj3/Project-3-Related-Files/Tests/world-tests/outside-world";
	// const string speciesSummaryFile = "/Users/bingcheng/Desktop/VE280/proj3/Project-3-Related-Files/Tests/species";
	//file_handle(speciesFile, line_num, lines);
	const string speciesSummaryFile = argv[1];
	const string worldFile = argv[2]; 
	initWorld(wd, speciesSummaryFile, worldFile);
	cout<<world_t_string(wd);
	const grid_t grid = wd.grid;
	bool verbose = verbose_on(argc, argv);
	cout<<"是否全输出？"<<verbose<<endl;
	int rounds = atoi(argv[3]);
	cout<<"rounds"<<rounds ;
	point_t location;
	location.r = 2;
	location.c = 2;
	bool exist;
	creature_t &creature = *getCreature(wd.grid, location, exist);
	cerr<<"direction "<<creature.direction<<endl;


// cout<<wd.creatures[0].species->name<<" "<< wd.creatures[1].species->name<<endl;
// 	for (int i = 0; i < wd.creatures[0].species->programSize; ++i)
// 	{
// 		cout<<opName[wd.creatures[0].species->program[i].op]<<endl;
// 	}
// 	for (int i = 0; i < wd.creatures[1].species->programSize; ++i)
// 	{
// 		cout<<opName[wd.creatures[1].species->program[i].op]<<endl;
// 	}

cout<<"Initial state"<<endl;
printGrid(grid);
	if (exist == true) {
		//cerr<<"name "<<creature.species->name<<endl;
		//cerr<<"op "<<opName[getInstruction(creature).op]<<" "<< getInstruction(creature).address<<endl;
		//simulateCreature(creature, wd.grid, true);
	}

simulation(wd, verbose, rounds);

	// cout<<wd.creatures[0].species->name<<" "<< wd.creatures[1].species->name<<endl;
	// for (int i = 0; i < wd.creatures[0].species->programSize; ++i)
	// {
	// 	cout<<opName[wd.creatures[0].species->program[i].op]<<endl;
	// }
	// for (int i = 0; i < wd.creatures[1].species->programSize; ++i)
	// {
	// 	cout<<opName[wd.creatures[1].species->program[i].op]<<endl;
	// }
	
	// direction_t dir = EAST;
	// cout<<"RIGHT:"<<endl;
	// point_t point;
	// set_point(point, 0,0);
	// for (int i = 0; i < 10; ++i)
	// {

	// 	cerr<<"direction: "<<directName[rightFrom(dir)]<<endl;
	// 	cout<<point_t_string(point);
	// 	point = adjacentPoint(point, dir);
	// 	dir = rightFrom(dir);
	// }
	// cout<<"LEFT:"<<endl;
	// for (int i = 0; i < 10; ++i)
	// {
	// 	cerr<<"direction: "<<directName[leftFrom(dir)]<<endl;
	// 	dir = leftFrom(dir);
	// }
}
























