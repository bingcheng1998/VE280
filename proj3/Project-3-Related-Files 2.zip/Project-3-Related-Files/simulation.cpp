#include "simulation.h"

#define DEBUG_SIM	//打开所有DEBUG输出

#define LOG_E	//打开ERROR    打开错误输出
//#define LOG_D	//打开DEBUG    打开测试输出
//#define LOG_V	//打开VERBOSE  打开文件


void debug_print(char TAG, string deb_string){
	#ifdef DEBUG_SIM
	#ifdef LOG_E
	if(TAG == 'e') cerr<< deb_string;
	#endif
	#ifdef LOG_D
	if(TAG == 'd') cerr<< deb_string;
	#endif
	#ifdef LOG_V
	if(TAG == 'v') cerr<< deb_string;
	#endif
	#endif
}
// static void debug_println(char TAG, string deb_string){
// 	#ifdef DEBUG_SIM
// 	#ifdef LOG_E
// 	if(TAG == 'e') cerr<< deb_string;
// 	#endif
// 	#ifdef LOG_D
// 	if(TAG == 'd') cerr<< deb_string;
// 	#endif
// 	#ifdef LOG_V
// 	if(TAG == 'v') cerr<< deb_string;
// 	#endif
// 	#endif
// }

bool ability_exist(string line, ability_t ability){      // -------------------------------------------
	bool ability_exist = false;
	bool none_sence_exist = false;
	//line = lines[h+2+i];
	//debug_stream<<"取出第 "<< i <<" 个生物: "<<line<<endl;
	string words[MAXARGINLINE];
	split(line, ' ', words);
	string invalid_ability;
	
	for (int j = 0; j < MAXABILITYNUM; ++j)
	{
		if(words[4+j]!="" && words[4+j]!="f" && words[4+j]!="a"){
			none_sence_exist = true;
		} else if (words[4+j] == abilityShortName[ability]){
			ability_exist = true;
		}
	}
	if (ability_exist && !none_sence_exist) return true;
	return false;
}

static void file_print(const string &file_name){
	ostringstream debug_stream;
	ifstream iFile;
	safe_open_file(iFile, file_name);
	debug_stream<<"😡-------------------文件内容开始--------------------"<<endl;
	string line;
	while(iFile) { 
		getline(iFile, line); 
		if(line == "") break;
		if(iFile) {
			debug_stream << line << endl; 
		}
	}
	debug_stream<<"😢-------------------文件内容结束--------------------"<<endl;
	iFile.close();
	cout<< debug_stream.str();
}

void file_handle(const string &file_name, int &line_num, string lines[]){
	ostringstream debug_stream;
	ifstream iFile;
	string line;
	safe_open_file(iFile, file_name);
	debug_stream<<"😡-------------------文件内容开始--------------------"<<endl;
	int line_now = 0;
	while(iFile) { 
		getline(iFile, line); 
		if(line == "") break;
		if(iFile) {
			debug_stream << line << endl; 
			lines[line_now] = line;
			line_now++;
		}
		
	}
	line_num = line_now;
	debug_stream<<"😢-------------------文件内容结束--------------------"<<endl;
	iFile.close();
	debug_print('v',debug_stream.str());
}

static terrain_t str2terrain(string words){
	for (int i = 0; i < TERRAIN_SIZE; i++)
	{
		if (terrainShortName[i] == words)
		{
			return terrain_t(i);
		}
	}
	return TERRAIN_SIZE;
}

static direction_t str2direction(string words){
	for (int i = 0; i < DIRECT_SIZE; i++)
	{
		if (directShortName[i] == words)
		{
			return direction_t(i);
		}
	}
	return DIRECT_SIZE;
}

static opcode_t str2opcode(string words){
	for (int i = 0; i < OP_SIZE; i++)
	{
		if (opName[i] == words)
		{
			return opcode_t(i);
		}
	}
	return OP_SIZE;
}

bool str_in_opcode(string words){
	for (int i = 0; i < OP_SIZE; i++)
	{
		if (opName[i] == words)
		{
			return true;
		}
	}
	return false;
}

void split(string String, char Char, string Splite[]){
	ostringstream debug_stream;
	const char *s = String.data();
	int length = String.length()+1;
	debug_stream<<"😝字符串分裂：\n总字符数"<<length-1<<", 内容为["<<s<<"]，以下为分裂后表示"<<endl;
	int arg_start = 0;
	int arg_length = 0;
	int arg_order = 0;
	for (int i = 0; i < length; ++i)
	{
		char arg_t[MAXARGINLINE+1];
		if (s[i] != Char && i!=length-1)
		{
			arg_length++;
		}
		if (arg_length != 0 && (s[i] == Char || i == length-1))
		{
			String.copy(arg_t, arg_length, arg_start);
			*(arg_t + arg_length) = '\0';
			Splite[arg_order] = arg_t;
			debug_stream<<"第["<<arg_order<<"]个，长度 ["
			<<arg_length<<"], 内容为["<<Splite[arg_order]<<"]"<<endl;
			arg_order++;
		}

		if (s[i] == Char)
		{
			arg_start = i+1;
			arg_length = 0;
		} else if(s[i] == '\0') {
			debug_stream<<"读到末尾符号 [\\0], 总共分为["<<arg_order<<"]部分, 跳出所有，结束分裂"<<endl; 
			break;
		}

	}
	//debug_print('d', debug_stream.str());
}

// static void world_message(const string &worldFile, int &h, int &w, terrain_t terrain[][MAXWIDTH]){//已完成！
// 	string line;
// 	string *lines = new string[MAXWORLDSIZE];
// 	int line_num;
// 	file_handle(worldFile, line_num, lines);
// 	h = atoi(lines[0].c_str());
// 	w = atoi(lines[1].c_str());
// 	for (int i = 0; i < h; ++i)
// 	{
// 		string words[MAXARGINLINE];
// 		line = lines[2+i];
// 		split(line, ' ', words);
// 		for (int j = 0; j < w; ++j)
// 		{
// 			terrain[i][j]=str2terrain(words[j]);
// 		}
// 	}
// 	delete[] lines;
// }

void world_message(const string &worldFile, int &h, int &w, terrain_t terrain[][MAXWIDTH], string &error_string){//已完成！
	string line;
	string *lines = new string[MAXWORLDSIZE];
	int line_num;
	file_handle(worldFile, line_num, lines);
	h = atoi(lines[0].c_str());
	w = atoi(lines[1].c_str());
	//cout<<"TERRAIN_SIZE = "<<TERRAIN_SIZE<<endl;
	for (int i = 0; i < h; ++i)
	{
		string words[MAXARGINLINE];
		line = lines[2+i];
		split(line, ' ', words);
		const char* c_word = words[0].data();
		for (int j = 0; j < w; ++j)
		{
			ostringstream sStream;
			sStream << c_word[j];
			terrain[i][j]=str2terrain(sStream.str());
			if(terrain[i][j] == TERRAIN_SIZE) error_string = sStream.str();
		}
	}
	delete[] lines;
}

int get_creature_num(const string &worldFile){//得到总生物实体个数
	ostringstream debug_stream;
	string line;
	string *lines = new string[MAXWORLDSIZE];
	int line_num;
	file_handle(worldFile, line_num, lines);
	int h = atoi(lines[0].c_str());
	//w = atoi(lines[1].c_str());
	int creature_num = 0;
	for (int i = h+2; i < line_num; ++i)
	{
		if(lines[i] == "\n") break;
		debug_stream<<lines[i]<<endl;
		creature_num++;
	}
	debug_stream<<"如上，生物总数: "<<creature_num<<endl;
	debug_print('v', debug_stream.str());
	return creature_num;
}
 
creature_t creature_make(const string &speciesSummaryFile, const string &worldFile, int num, point_t& location){//制造第num个生物实体
	ostringstream debug_stream;
	creature_t creature;
	int creature_num = get_creature_num(worldFile);
	if(num>creature_num) cerr<<"creature_make failed, num>creature_num";
	string line;
	string *lines = new string[MAXWORLDSIZE];
	int line_num;
	file_handle(worldFile, line_num, lines);
	int h = atoi(lines[0].c_str());
	//int w = atoi(lines[1].c_str());
	line = lines[h+2+num];
	creature.ability[FLY] = false;
	creature.ability[ARCH] = false;
	creature.hillActive = false;
	debug_stream<<"取出第 "<< num <<" 个生物: "<<line<<endl;
	string words[MAXARGINLINE];
	split(line, ' ', words);
	//cout<<"["<<creature.species.name<<"]"<<endl;
	species_t species;
	get_species_by_name(speciesSummaryFile, words[0], species);
	creature.species = &species;
	cout<<"NAME!名称🦁"<<creature.species->name<<endl;
	creature.species = &species;
	location.r = atoi(words[2].c_str());
	location.c = atoi(words[3].c_str());
	direction_t direction = str2direction(words[1]);
	creature.location = location;
	creature.direction = direction;
	creature.programID = 0;
	if(ability_exist(line, FLY)) creature.ability[FLY] = true;
	if(ability_exist(line, ARCH)) creature.ability[ARCH] = true;
	cerr<<"😁位置："<<creature.location.c<<endl;
	
	debug_print('v', debug_stream.str());
	return creature;
}

static grid_t grid_make(const string &speciesSummaryFile, const string &worldFile, int& creature_num, world_t &wt){ //向grid_t 中间填充所有数据
	//grid_t grid;
	creature_t creatures[MAXCREATURES];
	grid_t grid;
	//int terrain_m[MAXHEIGHT+1][MAXWIDTH+1];
	creature_num = get_creature_num(worldFile);
	creature_t creature_grid[MAXHEIGHT][MAXWIDTH];
	point_t location;
	for (int i = 0; i < creature_num; ++i)
	{
		// creatures[i] = wt.creatures[i];
		// wt.creatures[i] = creatures[i];
		wt.creatures[i] = creature_make(speciesSummaryFile, worldFile, i, location);
		cout<<"wt.creatures[i]"<<wt.creatures[i].species->name<<endl;
		wt.grid.squares[location.r][location.c] = &wt.creatures[i];
		cout<<"😤位置！"<<wt.grid.squares[wt.creatures[i].location.r][wt.creatures[i].location.c]->location.c<<"; "<<endl;
		cout<<"名称🌙"<<wt.grid.squares[location.r][location.c]-> species->name<<endl;
		//cout<<"😢位置？"<<creatures[i].location.c<<endl;
	}
	int h, w;
	//terrain_t terrain[MAXHEIGHT][MAXWIDTH];
	string none;
	world_message(worldFile, h, w, wt.grid.terrain, none);
	wt.grid.height = h;
	wt.grid.width = w;
	//grid.squares = creature_grid;
	//grid.terrain = terrain;
	//return grid;
	//grid0 = grid;
	//wt.creatures = creatures;
	//wt.grid = grid;
}

int get_line_num(const string &iFile){
	stringstream debug_stream;
	string line;
	string *lines = new string[MAXWORLDSIZE];
	int line_num;
	file_handle(iFile, line_num, lines);
	//cout<<"line_num = "<<line_num;
	return line_num;
}

string get_speciesFile(const string &speciesSummaryFile, int creature_num, string & name){
	stringstream debug_stream;
	int num = creature_num;
	if(get_line_num(speciesSummaryFile)-1<creature_num) {cerr<<"creature_num is to large! <get_speciesFile()>"<<endl; num = 0;}
	const char *s = speciesSummaryFile.data();
	char path[MAXPATHLENGTH];
	int length = speciesSummaryFile.length();
	int current_path_length = 0;
	ostringstream path_stream;
	for (int i = length; i >0; --i)
	{
		if(s[i] == '/'){
			i++;
			speciesSummaryFile.copy(path, i, 0);
			
			current_path_length = i;
			break;
		}
	}
	*(path + current_path_length) = '\0';
	string line;
	string *lines = new string[MAXWORLDSIZE];
	int line_num;
	file_handle(speciesSummaryFile, line_num, lines);
	name = lines[num+1];
	path_stream<<path<<lines[0]<<'/'<<name;
	//*(path + current_path_length) = '\0';
	debug_stream<<"路径"<<num<<": "<<path_stream.str()<<endl;
	debug_print('v', debug_stream.str());
	return path_stream.str();
}

static species_t specie_make_one(const string &speciesFile, string name){//生物种类 即tests/species文件 物种：名字，可执行的操作*数量  <已完成>
	species_t species;
	string line;
	string *lines = new string[MAXWORLDSIZE];
	int line_num;
	file_handle(speciesFile, line_num, lines);
	
	species.name = name;
	species.programSize = get_line_num(speciesFile);
	for (int i = 0; i < species.programSize; ++i)
	{
		line = lines[i];
		string words[MAXARGINLINE];
		split(line, ' ', words);
		species.program[i].op = str2opcode(words[0]);
		if(species.program[i].op>3) species.program[i].address = atoi(words[1].c_str());
	}
	delete[] lines;
	cout<<"种类名称🐰"<<species.name;
	return species;
}
void get_species_by_name(const string &speciesSummaryFile, string name, species_t &species1){
	species_t species;
	int species_num = get_line_num(speciesSummaryFile)-1;
	for (int i = 0; i < species_num; ++i)
	{
		//file_print(get_speciesFile(speciesSummaryFile, i));
		string name_get;
		string path = get_speciesFile(speciesSummaryFile, i,name_get);
		if(name == name_get){
			species = specie_make_one(path, name);
			cout<<"成功🦋！"<<endl;
			cerr<<"种类名称🐯"<<species.name;
		}
		// species[i] = specie_make_one(path, name);
		// //cout<<species_t_string(species[i]);
	}
	species1 = species;
	//return species;
}

static void species_make(const string &speciesSummaryFile, int& species_num, species_t species[]){
	//从speciesSummaryFile中间提取出来 speciesFile，然后make很多个specie_make_one，合成一个

	species_num = get_line_num(speciesSummaryFile)-1;
	for (int i = 0; i < species_num; ++i)
	{
		//file_print(get_speciesFile(speciesSummaryFile, i));
		string name;
		string path = get_speciesFile(speciesSummaryFile, i,name);
		species[i] = specie_make_one(path, name);
		//cout<<species_t_string(species[i]);
	}
	
}

bool initWorld(world_t &world, const string &speciesSummaryFile, const string &worldFile){
	ostringstream debug_stream;

	int creature_num;

	int h, w;
	terrain_t terrain[MAXHEIGHT][MAXWIDTH];
	string none;
	world_message(worldFile, h, w, terrain, none);
	debug_stream<<"h: "<<h<<", w:"<<w<<";"<<endl;
	int species_num;
	species_make(speciesSummaryFile, species_num, world.species);

	//grid_t grid_world;
	//creature_t creatures[MAXCREATURES];
	//species_t species[MAXSPECIES];
	cerr<<"start1"<<endl;
	grid_make(speciesSummaryFile, worldFile, creature_num, world);
	int i = 0;
	cerr<<"drd: "<<world.creatures[0].location.r<<"?/"<<endl;
	cerr<<"drd: "<<world.grid.squares[world.creatures[i].location.r][world.creatures[i].location.c]->location.r<<"?/"<<endl;
	cerr<<"drd: "<<world.grid.squares[world.creatures[i].location.r][world.creatures[i].location.c]->species->name<<"?/"<<endl;
	//int species_num;
	
	

	world.numSpecies = species_num;
	world.numCreatures = creature_num;

	//world.grid = grid_world;

	//world.species = species;

	debug_print('e', debug_stream.str());
	return true;
}

bool safe_open_file(ifstream& i_file, string file_name){
	ostringstream debug_stream;
	i_file.open(file_name.c_str());
	debug_stream<<"正在尝试打开文件："<<file_name<<endl;
	if (i_file.fail()) {cout<<"Error: Cannot open file "<< file_name<<endl; exit(-3); return false;}
	debug_stream<<"文件打开成功"<<endl;
	debug_print('v', debug_stream.str());
	return true;
}

string instruction_t_string(instruction_t it){
	ostringstream oStream; 
	oStream <<"op:"<<opName[it.op]<<", address:"<<it.address<<";";
	return oStream.str();
}

string species_t_string(species_t st){//有待改进，<<instruction_t_string(st.program[0]); 应该放到循环里面
	ostringstream oStream; 
	oStream <<"name:"<<st.name<<", programSize:"<<st.programSize<<", "<<endl;
	for (int i = 0; i < st.programSize; ++i)
	{
		oStream<<"NO."<<i<<" "<<instruction_t_string(st.program[i])<<endl;
	}
	return oStream.str();
}
string creature_t_string(creature_t ct);

string grid_t_string(grid_t gt);

string world_t_string(world_t wt){
	ostringstream oStream; 
	oStream <<"numSpecies: "<< wt.numSpecies<<"; numCreatures: "<<wt.numCreatures<<"; grid H: "<<wt.grid.height<<"; W: " << wt.grid.width<<"; terrain: "<<endl;
	for (int i = 0; i < wt.grid.height; ++i)
	{
		for (int j = 0; j < wt.grid.width; ++j)
		{
			oStream <<terrainShortName[wt.grid.terrain[i][j]]<<" ";
		}
		oStream<<endl;
	}
	return oStream.str();
}

// -------------------------------------------------------------------------------------------------------------

void simulateCreature(creature_t &creature, grid_t &grid, bool verbose);
// REQUIRES: creature is inside the grid.
// MODIFIES: creature, grid, cout.
// EFFECTS:	Simulate one turn of "creature" and update the creature, the infected creature, and the grid if necessary.
//The creature programID is always updated. The function also prints to the stdout the procedure. If verbose is true, it prints more information.
void printGrid(const grid_t &grid)
// MODIFIES: cout.
//
// EFFECTS: print a grid representation of the creature world.
{
	cout<<"H: "<<grid.height<<"; W: "<<grid.width<<endl;
	for (int i = 0; i < grid.height; ++i)
	{
		for (int j = 0; j < grid.width; ++j)
		{
			if(grid.squares[i][j]->location.r == i && grid.squares[i][j]->location.c == j){
				//cout<<"grid-> "<<grid.squares[j][i]->location.c<<grid.squares[j][i]->location.c<<" ";
				cout<<grid.squares[i][j]-> species->name<<"yes";
			} else {
				cout<<"?";
			}
			
			//grid.squares[location.r][location.c]->location.c
		}
		cout<<endl;
	}
}
point_t adjacentPoint(point_t pt, direction_t dir);
// EFFECTS: Returns a point that results from moving one square // in the direction "dir" from the point "pt".
direction_t leftFrom(direction_t dir);
// EFFECTS: Returns the direction that results from turning // left from the given direction "dir".
direction_t rightFrom(direction_t dir);
// EFFECTS: Returns the direction that results from turning // right from the given direction "dir".
instruction_t getInstruction(const creature_t &creature); // EFFECTS: Returns the current instruction of "creature".
creature_t *getCreature(const grid_t &grid, point_t location);
// REQUIRES: location is inside the grid.
//
// EFFECTS: Returns a pointer to the creature at "location" in "grid".
