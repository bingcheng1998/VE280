#include "simulation.h"
#include <string.h>

void error_exit(const string error,int exit_state){
	ostringstream debug_stream;
	debug_stream<<error<<endl;
	debug_print('e', debug_stream.str());
	exit(exit_state);
	//exit(0);
	return;
}

void check_args(int argc, char *argv[]){
	ostringstream debug_stream;
	if (argc<4){
		error_exit("Error: Missing arguments!\nUsage: ./p3 <species-summary> <world-file> <rounds> [v|verbose]", 1);
	}
	if (atoi(argv[3])<0) error_exit("Error: Number of simulation rounds is negative!", 2);
	ifstream iFile;
	safe_open_file(iFile, argv[1]);
	iFile.close();
	safe_open_file(iFile, argv[2]);
	iFile.close();
	ostringstream oStream;
	debug_print('e', debug_stream.str());
	string species_name[MAXSPECIES];
	int species_num = get_line_num(argv[1])-1;
	if(species_num > int(MAXSPECIES)){
		oStream<<"Error: Too many species!\nMaximal number of species is "<<MAXSPECIES<<".";
		error_exit(oStream.str(), 4);
	}
	bool species_too_much = false;
	for (int i = 0; i < species_num; ++i)
	{
		string name;
		ostringstream sStream;
		string path = get_speciesFile(argv[1], i,name);
		species_name[i] = name;
		if(get_line_num(path)>int(MAXPROGRAM)){
			sStream<<"Error: Too many instructions for species "<<name<<"!\nMaximal number of instructions is "<<MAXPROGRAM<<"."<<endl;
			cout<<sStream.str();
			species_too_much = true;
		}
	}
	if(species_too_much) exit(5);
	for (int i = 0; i < species_num; ++i)
	{
		string name;
		ostringstream sStream;
		string line;
		string lines[MAXWORLDSIZE];
		string path = get_speciesFile(argv[1], i,name);
		debug_stream<<"species <"<<name<<">"<<endl;
		int programSize;

		file_handle(path, programSize, lines);
		

		for (int j = 0; j < programSize; ++j)
		{
			string operation;
			line = lines[j];
			string words[MAXARGINLINE];
			split(line, ' ', words);
			operation = words[0];
			debug_stream<<"operation: "<<operation<<endl;
			if(!str_in_opcode(operation)){
				debug_print('d', debug_stream.str());
				oStream<<"Error: Instruction "<<operation<<" is not recognized!"<<endl;
				error_exit(oStream.str(), 6);
			}
		}
	}
//------------------------------* 7,8,9 *-----------------------------------//
	int h, w;
	string error_string = "No Error";
	terrain_t terrain[MAXHEIGHT][MAXWIDTH];
	world_message(argv[2], h, w, terrain, error_string);
	if(h>int(MAXHEIGHT)) error_exit("Error: The grid height is illegal!", 7);
	if(w>int(MAXWIDTH)) error_exit("Error: The grid width is illegal!", 8);
	for (int i = 0; i < h; ++i)
	{
		for (int j = 0; j < w; ++j)
		{
			if(terrain[i][j] == TERRAIN_SIZE){
				oStream<<"Error: Terrain square ("<<error_string<<" "<<i<<" "<<j<<") is invalid!"<<endl;
				error_exit(oStream.str(), 9);
			}
		}
	}
//------------------------------* 10 *-----------------------------------//
	int creature_num = get_creature_num(argv[2]);
	debug_stream<<"creature_num: "<<creature_num<<endl;
	if(creature_num > int(MAXCREATURES)) {
		oStream<<"Error: Too many creatures!\nMaximal number of creatures is "<<MAXCREATURES<<"."<<endl;
		error_exit(oStream.str(), 10);
	}
//------------------------------* 11 *-----------------------------------//
	string line;
	string lines[MAXWORLDSIZE];
	int line_num;
	file_handle(argv[2], line_num, lines);
	for (int i = 0; i < creature_num; ++i)
	{
		bool creature_exist = false;
		line = lines[h+2+i];
		string words[MAXARGINLINE];
		split(line, ' ', words);
		for (int i = 0; i < species_num; ++i)
		{
			if(species_name[i] == words[0]) {creature_exist = true;}
		}
		if (!creature_exist) {
			oStream<<"Error: Species "<<words[0]<<" not found!";
			error_exit(oStream.str(), 11);
		}
	}
//------------------------------* 12 *-----------------------------------//
	for (int i = 0; i < creature_num; ++i)
	{
		bool direction_exist = false;
		line = lines[h+2+i];
		string words[MAXARGINLINE];
		split(line, ' ', words);
		for (int i = 0; i < DIRECT_SIZE; ++i)
		{
			if(directName[i] == words[1]) {direction_exist = true;}
		}
		if (!direction_exist) {
			oStream<<"Error: Direction "<<words[1]<<" is not recognized!";
			error_exit(oStream.str(), 11);
		}
	}
//------------------------------* 13 *-----------------------------------//
	for (int i = 0; i < creature_num; ++i)
	{
		bool creature_out_of_bound = false;
		line = lines[h+2+i];
		string words[MAXARGINLINE];
		split(line, ' ', words);
		int creature_h = atoi(words[2].c_str());
		int creature_w = atoi(words[3].c_str());
		if(creature_h+1>h || creature_w+1>w) {creature_out_of_bound = true;}
		if (creature_out_of_bound) {
			oStream<<"Error: Creature ("<<words[0]<<" "<<words[1]<<" "<<words[2]<<" "<<words[3]<<") is out of bound!\nThe grid size is "<<h<<"-by-"<<w<<".";
			error_exit(oStream.str(), 13);
		}
	}
//------------------------------* 14 *-----------------------------------//
	for (int i = 0; i < creature_num; ++i)
	{
		bool creature_ability_invalid  = false;
		line = lines[h+2+i];
		string words[MAXARGINLINE];
		split(line, ' ', words);
		string invalid_ability;
		for (int j = 0; j < MAXABILITYNUM; ++j)
		{
			if(words[4+j]!="" && words[4+j]!="f" && words[4+j]!="a"){
				creature_ability_invalid = true;
				invalid_ability = words[4+j];
			}
		}
		if (creature_ability_invalid) {
			oStream<<"Error: Creature ("<<words[0]<<" "<<words[1]<<" "<<words[2]<<" "<<words[3]<<") has an invalid ability "<<invalid_ability<<"!"<<endl;;
			error_exit(oStream.str(), 14);
		}
	}
//------------------------------* 15 *-----------------------------------//
	point_t creatures_A_B;
	point_t points[MAXCREATURES];
	bool creature_overlaps  = false;
	for (int i = 0; i < creature_num; ++i)
	{
		line = lines[h+2+i];
		string words[MAXARGINLINE];
		split(line, ' ', words);
		points[i].r = atoi(words[2].c_str());
		points[i].c = atoi(words[3].c_str());
		for (int j = 0; j < i; ++j)
		{
			if(points[i].r == points[j].r && points[i].c == points[j].c){
				creature_overlaps = true;
				creatures_A_B.r = i;
				creatures_A_B.c = j;
			}
		}
	}

	if (creature_overlaps) {
		string words[MAXARGINLINE];
		split(lines[creatures_A_B.r+2+h], ' ', words);
		oStream<<"Error: Creature ("<<words[0]<<" "<<words[1]<<" "<<words[2]<<" "<<words[3]<<") overlaps with creature (";
		split(lines[creatures_A_B.c+2+h], ' ', words);
		oStream<<words[0]<<" "<<words[1]<<" "<<words[2]<<" "<<words[3]<<")!"<<endl;
		error_exit(oStream.str(), 15);
	}
//------------------------------* 16 *-----------------------------------//
	for (int i = 0; i < h; ++i)
	{
		for (int j = 0; j < w; ++j)
		{
			if(terrain[i][j] == LAKE){
				debug_stream<<i<<" "<<j <<" = lake"<<endl;
				for (int k = 0; k<creature_num; ++k){
					string words[MAXARGINLINE];
					split(lines[k+2+h], ' ', words);
					if (atoi(words[2].c_str()) == i && atoi(words[3].c_str()) == j) {
						if (!ability_exist(lines[k+2+h], FLY))
						{
							oStream<<"Error: Creature ("<<words[0]<<" "<<words[1]<<" "<<words[2]<<" "<<words[3]<<") is in a lake square!"<<endl;
							error_exit(oStream.str(), 16);
						}
					}
				}
			}
		}
	}
}

bool verbose_on(int argc, char *argv[]){
	if(argc == 4) return false;
	if(strcmp(argv[4] , "v") == 0 || strcmp(argv[5],"verbose")) return true;
	return false;
}

int main(int argc, char *argv[]) {
	check_args(argc, argv);
	world_t wd;
	const string speciesSummaryFile = argv[1];
	const string worldFile = argv[2]; 
	initWorld(wd, speciesSummaryFile, worldFile);
	const grid_t grid = wd.grid;
	bool verbose = verbose_on(argc, argv);
	int rounds = atoi(argv[3]);
	cout<<"Initial state"<<endl;
	printGrid(grid);
	simulation(wd, verbose, rounds);

	// cout<<wd.creatures[0].species->name<<" "<< wd.creatures[1].species->name<<endl;
	// for (int i = 0; i < wd.creatures[0].species->programSize; ++i)
	// {
	// 	cout<<opName[wd.creatures[0].species->program[i].op]<<endl;
	// }
	// for (int i = 0; i < wd.creatures[1].species->programSize; ++i)
	// {
	// 	cout<<opName[wd.creatures[1].species->program[i].op]<<endl;
	// }
	
	// direction_t dir = EAST;
	// cout<<"RIGHT:"<<endl;
	// point_t point;
	// set_point(point, 0,0);
	// for (int i = 0; i < 10; ++i)
	// {

	// 	cerr<<"direction: "<<directName[rightFrom(dir)]<<endl;
	// 	cout<<point_t_string(point);
	// 	point = adjacentPoint(point, dir);
	// 	dir = rightFrom(dir);
	// }
	// cout<<"LEFT:"<<endl;
	// for (int i = 0; i < 10; ++i)
	// {
	// 	cerr<<"direction: "<<directName[leftFrom(dir)]<<endl;
	// 	dir = leftFrom(dir);
	// }
	return 0;
}
























