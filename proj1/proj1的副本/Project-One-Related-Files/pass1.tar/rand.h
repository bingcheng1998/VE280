#ifndef __RAND_H__
#define __RAND_H__

void p1_srand(int);
// EFFECTS: initializes the seed
int p1_rand();
// EFFECTS: returns a random number between 13 and 39

#endif /* __RAND_H__ */
