#ifndef __VE280_P1_H__
#define __VE280_P1_H__
#include "rand.h"
#include <string>

const std::string words[] = {
   "awkward",
   "bagpipes",
   "banjo",
   "bungler",
   "croquet",
   "crypt",
   "dwarves",
   "fervid",
   "fishhook",
   "fjord",
   "gazebo",
   "gypsy",
   "haiku",
   "haphazard",
   "hyphen",
   "ivory",
   "jazzy",
   "jiffy",
   "jinx",
   "jukebox",
   "kayak",
   "kiosk",
   "klutz",
   "memento",
   "mystify",
   "numbskull",
   "ostracize",
   "oxygen",
   "pajama",
   "phlegm",
   "pixel",
   "polka",
   "quad",
   "quip",
   "rhythmic",
   "rogue",
   "sphinx",
   "squawk",
   "swivel",
   "toady",
   "twelfth",
   "unzip",
   "waxy",
   "wildebeest",
   "yacht",
   "zealous",
   "zigzag",
   "zippy",
   "zombie"
};

const int nWords = 49;

#endif
