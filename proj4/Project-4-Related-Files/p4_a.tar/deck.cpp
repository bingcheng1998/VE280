#include "deck.h"
#include <iostream>

using namespace std;

//#define PRINT_DECK
//#define CHECK_DECK

static void print_deck(Card* card ,int n){
#ifdef PRINT_DECK
    cout<<"🐑打印 "<<n+1<<" 张牌："<<endl;
    for (int i = 0; i < n; ++i)
    {
        cout<<"(["<<i<<"] "<<SuitNames[card[i].suit]<<", "<<SpotNames[card[i].spot]<<")\t";
        if((i+1)%5 == 0 && i != n) cout<<endl;
    }
    cout<<"\n🖨 打印结束"<<endl;
#endif
}

static void check(Card* deck){
#ifdef CHECK_DECK
    int card[SUIT_SIZE][SPOT_SIZE];
    for (int i = 0; i < SPOT_SIZE; ++i)
    {
        for (int j = 0; j < SUIT_SIZE; ++j)
        {
            card[j][i] = 0;
        }
    }
    for (int i = 0; i < DeckSize; ++i)
    {
        for (int j = 0; j < SUIT_SIZE; ++j)
        {
            for (int k = 0; k < SPOT_SIZE; ++k)
            {
                if (deck[i].spot == Spot(k) && deck[i].suit == Suit(j))
                {
                    card[j][k] ++;
                }
            }
        }
    }
    for (int i = 0; i < SPOT_SIZE; ++i)
    {
        for (int j = 0; j < SUIT_SIZE; ++j)
        {
            if(card[j][i]!=1) {
                const Spot spot = Spot(i);
                const Suit suit = Suit(j);
                cout<<"验证失败！有 card["<<(suit)<<"，"<<(spot)<<"] 张数是"<<card[j][i]<<endl;
                exit(0);
            }
        }
    }
    cout<<"所有牌组验证通过！没有重复"<<endl;
#endif
}


Deck::Deck():next(0)
{
    for (int j = 0; j < SUIT_SIZE; ++j)
    {
        for (int i = 0; i < SPOT_SIZE; ++i)
        {
            deck[i+j*SPOT_SIZE].spot = Spot(i);
            deck[i+j*SPOT_SIZE].suit = Suit(j);
        }
    }
    next = 0;
    check(deck);
    print_deck(deck, 52); //check all 
}

void Deck::reset()
{
    Deck();
}

void Deck::shuffle(int n)
{
    cout<<"cut at "<< n <<endl;
    Card deck_new[DeckSize];
    int left = 0, right = n;
    int shuffled = min(n, DeckSize-n);
    bool L = false;
    // for (int i = 0; i < DeckSize; ++i)
    // {
    //     deck_new[i] = deck[i];
    // }
    for (int i = 0; i < shuffled*2; ++i)
    {
        if (L) {
            deck_new[i] = deck[left];
            left ++;
        } else {
            deck_new[i] = deck[right];
            right ++;
        }
        L = !L;
    }
    if (n > DeckSize - n)
    {
        for (int i = 0; i < n - (DeckSize - n); ++i)
        {
            deck_new[shuffled*2+i] = deck[shuffled+i];
        }
    } else if (n < DeckSize - n) 
    {
        for (int i = 0; i < (DeckSize - n) - n; ++i)
        {
            deck_new[shuffled*2+i] = deck[2*shuffled+i];
        }
    }

    for (int i = 0; i < DeckSize; ++i)
    {
        deck[i] = deck_new[i];
    }
    check(deck);
    print_deck(deck, 52); //check all 
    next = 0;
}



Card Deck::deal()
{
    Card card = deck[next];
    next++;
    if(cardsLeft() == 0){
        DeckEmpty deckEmpty;
        throw(deckEmpty);
    }
    return card;
}

int Deck::cardsLeft()
{
    return DeckSize - next;
}







